#include "shell.h"

// macro maximum input length
#define MAX_LENGTH	100

// variable used to determine number of pipes to use
// global for recursive purposes
int length;

// a valid word must only contain the characters in this array
char validchars[66] = {'A','a','B','b','C','c','D','E','e','F','f','G','g','H','h','I','i',
'J','j','K','k','L','l','M','m','N','n','O','o','P','p','Q','q','R','r','S','s','T','t','U',
'u','V','v','W','w','X','x','Y','y','Z','z','0','1','2','3','4','5','6','7','8','9','-','_','.','/'};

// check if char* is only made of validchars
// return true or false
bool word(char* str) {
	bool test = false;
	for (unsigned int i = 0; i < strlen(str); i++) {
		for(int i = 0; i < 66; i++) {
			test = false;
			if(*str == validchars[i]) {
				test = true;
				break;
			}
		}
		str++;
	}
	return test;
}

// determine file redirections within token
// outputs an int that means either both are present or only one-- and which one
// for parsing < and > without spaces
int lt_gt(char* str) {
	bool lt = false;
	bool gt = false;
	for(char* iter = str; *iter; ++iter) {
		if (*iter == '>') {
			gt = true;
		} else if (*iter == '<') {
			lt = true;
		}
	}
	if(lt && gt) {
		return 3;
	} else if (gt) {
		return 2;
	} else if (lt) {
		return 1;
	} else {
		return 0;
	}
}

// function to print an error message to stdout
void PrintError() {
	printf("invalid input\n");
}

// state machine implementation for parsing token groups and executing them
// piping is not handled in this function (other than files)
void parse(vector<char*> list, int single) {
	vector<char*>::iterator iter = list.begin();
	ParseState state = Start;
	char* command;
	vector<char*> args;
	int inFile = 0;
	int outFile = 0;
	while(!list.empty()) {
		// go to execute state, break while loop
		if(iter == list.end()) {
				list.clear();
				state = ExecuteCommand;
		}
		switch(state) {
			// get command
			case Start:
				if(!word(*iter)) {
					PrintError();
					list.clear();
					break;
				} else {
					command = *iter;
					args.push_back(*iter);
					iter++;
					state = CheckWord;
				}
				break;
			// if word, add to args
			case CheckWord:
				if(!word(*iter)) {
					state = CheckOperator;
				} else {
					args.push_back(*iter);
					iter++;
				}
				break;
			// if operator, handle files, otw -> ERROR
			case CheckOperator:
				if(strcmp(*iter, "<") == 0) {
					iter++;
					state = InputRedirection;
				} else if(strcmp(*iter, ">") == 0) {
					iter++;
					state = OutputRedirection;
				} else {
					PrintError();
					list.clear();
				}
				break;
			// handle input file pipe
			case InputRedirection:
				inFile = open(*iter, O_RDONLY);
				iter++;
				state = CheckWord;
				break;
			// handle outout file pipe
			case OutputRedirection:
				outFile = open(*iter, O_WRONLY | O_TRUNC | O_CREAT,S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
				iter++;
				state = CheckWord;
				break;
			// set up and call execvp by forking a child process
			case ExecuteCommand:
				int fd[2];
				pipe(fd);
				int pid_u = fork();
				if(pid_u == 0) {
					// set up input pipe
					if(inFile != 0) {
						dup2(inFile, 0);
						close(inFile);
					} else {
				 		close(fd[1]);
					// set up output pipe
					} if (outFile != 0) {
						dup2(outFile, 1);
						close(outFile);
					}
					// form c_args array
					char* c_args[args.size() + 1];
					vector<char*>::iterator iter2;
					int i = 0;
					for(iter2 = args.begin(); iter2 < args.end(); iter2++) {
						c_args[i] = *iter2;
						i++;
					}
					// add NULL as the last element
					c_args[i] = NULL;
					// use the cwd as the PATH
					char* cwd = (char*)malloc(100*sizeof(char));
					cwd = getcwd(cwd, 100);
					setenv("PATH", cwd, 1);
					extern char** environ;
					// execute and check for error
					int exec;
					exec = execve(command, c_args, environ);
					if(exec < 0) {
						printf("invalid input\n");
						exit(errno);
					}
				} else {
					//close the file pipes and print the status code to stderr
					close(fd[0]);
					close(fd[1]);
					int status = 0;
					waitpid(pid_u, &status, 0);
					fprintf(stderr, "%d\n", status);
				}
				break;
		}
	}
	return;
}

// simple function to close all pipes passed to it in the form of an int array
void close_pipes(int pipes[]) {
	for (int i = 0; i < length; i++) {
		close(pipes[i]);
	}
}

// piping is performed recursively, every token group results in a forked child calling the 'parse' function on it
// base case (vector size 0)
// special initial case (vector size = initial size i.e. first time the function is called)
// pipes[] is the array of pipes to use, size is the current size of the vector, input is for the read end, output -> write
void pipe_recursion(vector<vector<char*> > vec, int pipes[], int size, int input, int output) {
	// get the last item and then remove it from the vector
	vector<char*> current = vec.back();
	vec.pop_back();
	// base case, only pipe input
	if (vec.size() == 0) {
		int pid_r = fork();
		if(pid_r == 0) {
			// parse the token group
			dup2(pipes[length - 2], 0);
			close_pipes(pipes);
			parse(current, 1);
			exit(0);
		} else {
			// done
			return;
		}
	// initial case, only pipe output
	} else if (vec.size() == unsigned(size)) {
		int pid_r = fork();
		if(pid_r == 0) {
			dup2(pipes[1], 1);
			close_pipes(pipes);
			parse(current, 0);
			exit(0);
		}else {
			input += 2;
			output += 2;
			pipe_recursion(vec, pipes, size, input, output);
		}
	} else {
		// else pipe based on position in groups
		int pid_r = fork();
		if(pid_r == 0) {
			dup2(pipes[input], 0);
			dup2(pipes[output], 1);
			close_pipes(pipes);
			parse(current, 0);
			exit(0);
		} else {
			input += 2;
			output += 2;
			pipe_recursion(vec, pipes, size, input, output);
		}
	}
}

// while(1) loop, gather input, format vectors
int main(int argc, char** argv) {
	char *buf = (char*)malloc(sizeof(char)*1024);
	char *token;
	vector<char*> tokens;
	vector< vector<char*> > groups;
	while(1) {
		// fill char buffer with console input
		fgets(buf, 1024, stdin);
		if(feof(stdin)) {
			exit(0);
		}
		// remove trailing newline or carriage return
		for (int x = 0; (unsigned)x < strlen(buf); x++) {
			if ( buf[x] == '\n' || buf[x] == '\r' ) {
				buf[x] = '\0';
			}
		}
		// throw error if over 100 chars
		if (strlen(buf) > MAX_LENGTH) {
			printf("invalid input");
		}
		// exit program if input is 'exit'
		else if (strcmp(buf, "exit") == 0) {
			break;
		}
		else {
			// split buffer based on spaces and add to a vector
			token = strtok(buf," ");
			// if it's just spaces, start over
			if(token == NULL) {
			    PrintError();
			    continue;
			}
			while (token != NULL) {
				tokens.push_back(token);
				token = strtok(NULL," ");
			}
			vector<char*>::iterator it;
			vector<char*> temp;
			// restart if trailing pipe
			it = tokens.end() - 1;
			if(strcmp(*it, "|") == 0) {
				PrintError();	
				tokens.clear();
				continue;
			}
			// split each token based on pipes and put into nested list
			for (it = tokens.begin(); it < tokens.end(); it++) {
				if (strcmp(*it, "|") == 0) {
					if(it == tokens.end() - 1) {
					    PrintError();
					}
					groups.push_back(temp);
					temp.clear();
					continue;
				}
				else if (it == tokens.end() - 1) {
					temp.push_back(*it);
					groups.push_back(temp);
					temp.clear();
					continue;
				}
				temp.push_back(*it);
			}
			tokens.clear();
			vector<vector<char*> >::iterator its;
			vector<vector<char*> > groups_real;
			for(its = groups.begin(); its < groups.end(); its++) {
				// this for loop was added to handle file redirectors
				// not separated by spaces
				vector<char*> print = *its;
				for (it = print.begin(); it < print.end(); it++) {
					if(!word(*it)) {
						int check = lt_gt(*it);
						char * dummy = *it;
						if(strcmp(*it, "<") == 0) {
							tokens.push_back((char*)"<");
						} else if (strcmp(*it, ">") == 0) {
							tokens.push_back((char*)">");
						// both
						} else if (check == 3) {
							char * lt = strtok(dummy, "<");
							tokens.push_back(lt);
							tokens.push_back((char*)"<");
							lt = strtok(NULL, "<");
							tokens.push_back(lt);
							char * gt = strtok(lt, ">");
							tokens.push_back((char*)">");
							gt = strtok(NULL, ">");
							tokens.push_back(gt);
						// greater than
						} else if (check == 2) {
							char * gt = strtok(dummy, ">");
							tokens.push_back(gt);
							tokens.push_back((char*)">");
							gt = strtok(NULL, ">");
							tokens.push_back(gt);
						// less than
						} else if (check == 1) {
							char * lt = strtok(dummy, "<");
							tokens.push_back(lt);
							tokens.push_back((char*)"<");
							lt = strtok(NULL, "<");
							tokens.push_back(lt);
						// if it's another configuration, it's invalid
						} else {
							PrintError();
						}
					} else {
						tokens.push_back(*it);
					}
				}
				groups_real.push_back(tokens);
				tokens.clear();
			}
			vector<vector<char*> > reverse;
			vector<vector<char*> >::iterator r_it;
			// reverse the groups for recursive piping
			for(r_it = groups_real.end() - 1; r_it >= groups_real.begin(); r_it--) {
				reverse.push_back(*r_it);
			}
			groups_real.swap(reverse);
			int size = groups_real.size();
			if(groups_real.size() > 1){
				// if there are pipes, use recursive piping function
				length = (groups_real.size() - 1) * 2;
				int pipes[length];
				for (int i = 0; i < length / 2; i++) {
					pipe(pipes + 2*i);
				}
				pipe_recursion(groups_real, pipes, groups_real.size(), -2, 1);
				close_pipes(pipes);
				for(int i = 0; i < size; i++) {
					wait(NULL);
				}
			// else just parse the one group
			} else {
				parse(groups_real.front(), 1);
			}
			// clear all the lists
			temp.clear();
			tokens.clear();
			groups.clear();
			groups_real.clear();
			// continue
		}
	}
	return 0;
}